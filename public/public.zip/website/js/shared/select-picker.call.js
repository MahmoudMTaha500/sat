$('.selectpicker').selectpicker();
// Placeholder inputs of search
$('.bs-searchbox input').attr('placeholder',` ابحث هنا`)