<template>
  <vuejs-datepicker></vuejs-datepicker>
</template>


<script>

    import Datepicker from 'vuejs-datepicker';

export default {
  // ...
  components: {
    Datepicker
  }
  // ...
}
</script>

