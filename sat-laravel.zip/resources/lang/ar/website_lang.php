<?php 

return [
    'test' => 'اختبار',
    'your name' => 'الاسم الخاص بك',
    'your name must not exceed 255 letter' => 'يجب الا يتجاوز الاسم 255 حرف',
    'your email must not exceed 255 letter' => 'يجب الا يتجاوز البريد الالكتروني 255 حرف',
    'nationality' => 'الجنسية',
    'SAR' => 'الريال السعودي',
    'GBP' => 'الجنيه الاسترليني',
    'EUR' => 'اليورو الاروبي',
    'USD' => 'الدولار الامريكي',
    'CAD' => 'الدولار الكندي',
];