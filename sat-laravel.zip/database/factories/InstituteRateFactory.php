<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\InstituteRate;
use Faker\Generator as Faker;

$factory->define(InstituteRate::class, function (Faker $faker) {
    return [
        //
    ];
});
