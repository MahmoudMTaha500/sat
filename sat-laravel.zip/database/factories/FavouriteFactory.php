<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Favourite;
use Faker\Generator as Faker;

$factory->define(Favourite::class, function (Faker $faker) {
    return [
        //
    ];
});
