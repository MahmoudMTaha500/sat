<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\insurances;
use Faker\Generator as Faker;

$factory->define(insurances::class, function (Faker $faker) {
    return [
        //
    ];
});
