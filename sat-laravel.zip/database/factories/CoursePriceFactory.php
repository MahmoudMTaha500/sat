<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\CoursePrice;
use Faker\Generator as Faker;

$factory->define(CoursePrice::class, function (Faker $faker) {
    return [
        //
    ];
});
