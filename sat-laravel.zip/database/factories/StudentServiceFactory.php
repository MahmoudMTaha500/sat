<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\StudentService;
use Faker\Generator as Faker;

$factory->define(StudentService::class, function (Faker $faker) {
    return [
        //
    ];
});
