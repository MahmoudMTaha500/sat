<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\VisaQuestionChoices;
use Faker\Generator as Faker;

$factory->define(VisaQuestionChoices::class, function (Faker $faker) {
    return [
        //
    ];
});
