<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Visa;
use Faker\Generator as Faker;

$factory->define(Visa::class, function (Faker $faker) {
    return [
        //
    ];
});
