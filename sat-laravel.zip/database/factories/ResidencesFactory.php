<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\residences;
use Faker\Generator as Faker;

$factory->define(residences::class, function (Faker $faker) {
    return [
        //
    ];
});
