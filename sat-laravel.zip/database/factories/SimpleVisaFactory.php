<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\SimpleVisa;
use Faker\Generator as Faker;

$factory->define(SimpleVisa::class, function (Faker $faker) {
    return [
        //
    ];
});
