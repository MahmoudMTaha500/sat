<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\VisaQuestion;
use Faker\Generator as Faker;

$factory->define(VisaQuestion::class, function (Faker $faker) {
    return [
        //
    ];
});
