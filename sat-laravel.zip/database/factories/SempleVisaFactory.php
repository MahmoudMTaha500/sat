<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\SempleVisa;
use Faker\Generator as Faker;

$factory->define(SempleVisa::class, function (Faker $faker) {
    return [
        //
    ];
});
