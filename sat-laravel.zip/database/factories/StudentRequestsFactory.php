<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\StudentRequests;
use Faker\Generator as Faker;

$factory->define(StudentRequests::class, function (Faker $faker) {
    return [
        //
    ];
});
