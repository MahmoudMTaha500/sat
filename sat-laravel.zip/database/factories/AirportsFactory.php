<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\airports;
use Faker\Generator as Faker;

$factory->define(airports::class, function (Faker $faker) {
    return [
        //
    ];
});
