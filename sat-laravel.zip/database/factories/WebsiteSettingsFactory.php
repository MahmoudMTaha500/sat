<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\WebsiteSettings;
use Faker\Generator as Faker;

$factory->define(WebsiteSettings::class, function (Faker $faker) {
    return [
        //
    ];
});
