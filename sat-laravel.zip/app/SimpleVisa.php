<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SimpleVisa extends Model
{
    //
}
