<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SempleVisa extends Model
{
    protected $table='semple_visas';
    protected $guarded=[];

 }
