<?php

namespace App\Http\Controllers\Dashboard;

use App\Models\CoursePrice;
use Illuminate\Http\Request;

class CoursePriceController extends Controller
{

    public function index()
    {
        //
    }

 
    public function create()
    {
        //
    }


    public function store(Request $request)
    {
        //
    }

 
    public function show(CoursePrice $coursePrice)
    {
        //
    }

    public function edit(CoursePrice $coursePrice)
    {
        //
    }


    public function update(Request $request, CoursePrice $coursePrice)
    {
        //
    }

    public function destroy(CoursePrice $coursePrice)
    {
        //
    }
}
