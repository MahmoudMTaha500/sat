 <?php $__env->startSection('website.content'); ?> 
<div class="bg-sub-secondary-color">
 <!-- About Us -->
 <section class="about-us py-5">
    <div class="container-fluid">
        <!-- Section Heading -->
        <div class="row px-xl-5">
            <div class="col-12 ">
                <div class="heading-about-us">

                    <h3 class="text-main-color font-weight-bold">من نحن</h3>
                    <p>موقع سات هو نظام عالمي مختص بالبحث والحجز المباشر لكورسات اللغة ودورات التدريب والتقديم على
                        الجامعات حول العالم ويعد الأفضل لاحتوائه على أقوى المؤسسات التعليمية في نطاق واسع، بحيث يضم
                        أكثر من 350 معهد لتعليم اللغة الإنجليزية و 1,100 جامعة في اكثر من 20 دولة حول العالم </p>
                </div>
            </div>
        </div>
        <!-- ./Section Heading -->
    </div>

</section>
<!-- ./About Us -->
<!-- Brief -->
<section class="brief bg-white py-5">
    <div class="container-fluid">
        <div class="row px-xl-5">
            <div class="col-lg-4 mb-4 text-center">
                <!-- Img Brief -->
                <img src="<?php echo e(asset('website')); ?>/imgs/brief.png" alt="" class="img-fluid rounded-10">
                <!-- ./Img Brief -->
            </div>
            <div class="col-lg-8 align-self-center">
                <div class="heading-brief">

                    <h3 class="text-main-color font-weight-bold">نبذه عن فريق العمل والمعاهد</h3>
                    <p>موقع سات هو نظام عالمي مختص بالبحث والحجز المباشر لكورسات اللغة ودورات التدريب والتقديم على
                        الجامعات حول العالم ويعد الأفضل لاحتوائه على أقوى المؤسسات التعليمية في نطاق واسع، بحيث يضم
                        أكثر من 350 معهد لتعليم اللغة الإنجليزية و 1,100 جامعة في اكثر من 20 دولة حول العالم </p>
                    <a href="<?php echo e(route('website.institutes')); ?>"
                        class="btn rounded-10 bg-secondary-color text-center mb-3 text-white">تصفح المعاهد</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ./Brief -->
<!-- Team -->
<section class="team py-5" id="team">
    <div class="container-fluid">
        <!-- Section Heading -->
        <div class="row px-xl-5">
            <div class="col-lg-12">
                <div class="heading-team">

                    <h3 class="text-main-color font-weight-bold">الفريق</h3>
                    <p>لدينا أكثر من 60 موظف يعملون بتفانٍ على تقديم الدعم الكامل لطلابنا الزائرين لموقعنا وللرد على
                        الاستفسارات عن طريق المحادثة على الانترنت والهاتف والبريد الألكتروني</p>
                </div>
            </div>
        </div>
        <!-- ./Section Heading -->
        
    </div>

</section>
<!-- ./Team -->
<!-- Value & mission -->
<section class="value-mission py-5 bg-white">
    <div class="container-fluid">
        <!-- Section Heading -->
        <div class="row px-xl-5 mb-4">
            <div class="col-12">
                <div class="heading-team">

                    <h3 class="text-main-color font-weight-bold">عن الشركة و قيمها و مهمتها</h3>
                    <p>نسعى من خلال عقودنا واتفاقياتنا مع المعاهد والجامعات والمؤسسات الأكاديمية لرفع مستوى التعاون التعليمي بين المؤسسات وخلق بيئة تنافسية شريفة لتقديم اجود الخدمات للمتقدمين 
                        القيم التي تأسست عليها سات هى التعاون والعمل المشترك الإخلاص والمبادرة وشغفنا الشخصي بما نفعل</p>
                </div>
            </div>
        </div>
        <!-- ./Section Heading -->
        <div class="row px-xl-5">
            <div class="col-lg-4 col-md-6">
                <div class="bg-white shadow-lg rounded-10 py-3 mission px-xl-4 px-3 mb-4">
                    <!-- Mission Icon -->
                    <div class="mission-icon mb-3">
                        <i class="fas fa-tags text-main-color font-xl"></i>
                    </div>
                    <!-- ./Mission Icon -->
                    <!-- Mission Title -->
                    <div class="mission-title">
                        <h5 class="font-weight-bold">الاسعار</h5>
                    </div>
                    <!-- ./Mission Title -->
                    <!-- Mission Description -->
                    <div class="mission-description">
                        <p>تقديم الإستشارات التعليمية لاختيار التخصص الجامعى</p>
                    </div>
                    <!-- ./Mission Description -->
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="bg-white shadow-lg rounded-10 py-3 mission px-xl-4 px-3 mb-4">
                    <!-- Mission Icon -->
                    <div class="mission-icon mb-3">
                        <i class="fas fa-lightbulb text-main-color font-xl"></i>
                    </div>
                    <!-- ./Mission Icon -->
                    <!-- Mission Title -->
                    <div class="mission-title">
                        <h5 class="font-weight-bold">الإبداع</h5>
                    </div>
                    <!-- ./Mission Title -->
                    <!-- Mission Description -->
                    <div class="mission-description">
                        <p>تقديم الإستشارات التعليمية لاختيار التخصص الجامعى</p>
                    </div>
                    <!-- ./Mission Description -->
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="bg-white shadow-lg rounded-10 py-3 mission px-xl-4 px-3 mb-4">
                    <!-- Mission Icon -->
                    <div class="mission-icon mb-3">
                        <i class="fas fa-trophy text-main-color font-xl"></i>
                    </div>
                    <!-- ./Mission Icon -->
                    <!-- Mission Title -->
                    <div class="mission-title">
                        <h5 class="font-weight-bold">الجوائز</h5>
                    </div>
                    <!-- ./Mission Title -->
                    <!-- Mission Description -->
                    <div class="mission-description">
                        <p>تقديم الإستشارات التعليمية لاختيار التخصص الجامعى</p>
                    </div>
                    <!-- ./Mission Description -->
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="bg-white shadow-lg rounded-10 py-3 mission px-xl-4 px-3 mb-4">
                    <!-- Mission Icon -->
                    <div class="mission-icon mb-3">
                        <i class="fas fa-tags text-main-color font-xl"></i>
                    </div>
                    <!-- ./Mission Icon -->
                    <!-- Mission Title -->
                    <div class="mission-title">
                        <h5 class="font-weight-bold">الاسعار</h5>
                    </div>
                    <!-- ./Mission Title -->
                    <!-- Mission Description -->
                    <div class="mission-description">
                        <p>تقديم الإستشارات التعليمية لاختيار التخصص الجامعى</p>
                    </div>
                    <!-- ./Mission Description -->
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="bg-white shadow-lg rounded-10 py-3 mission px-xl-4 px-3 mb-4">
                    <!-- Mission Icon -->
                    <div class="mission-icon mb-3">
                        <i class="fas fa-tags text-main-color font-xl"></i>
                    </div>
                    <!-- ./Mission Icon -->
                    <!-- Mission Title -->
                    <div class="mission-title">
                        <h5 class="font-weight-bold">الاسعار</h5>
                    </div>
                    <!-- ./Mission Title -->
                    <!-- Mission Description -->
                    <div class="mission-description">
                        <p>تقديم الإستشارات التعليمية لاختيار التخصص الجامعى</p>
                    </div>
                    <!-- ./Mission Description -->
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="bg-white shadow-lg rounded-10 py-3 mission px-xl-4 px-3 mb-4">
                    <!-- Mission Icon -->
                    <div class="mission-icon mb-3">
                        <i class="fas fa-tags text-main-color font-xl"></i>
                    </div>
                    <!-- ./Mission Icon -->
                    <!-- Mission Title -->
                    <div class="mission-title">
                        <h5 class="font-weight-bold">الاسعار</h5>
                    </div>
                    <!-- ./Mission Title -->
                    <!-- Mission Description -->
                    <div class="mission-description">
                        <p>تقديم الإستشارات التعليمية لاختيار التخصص الجامعى</p>
                    </div>
                    <!-- ./Mission Description -->
                </div>
            </div>
            
        </div>
    </div>
</section>
<!-- ./Value & mission -->
<!-- Trusted Us -->

<!-- ./Trusted Us -->
</div>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sat-laravel\resources\views/website/about-us.blade.php ENDPATH**/ ?>