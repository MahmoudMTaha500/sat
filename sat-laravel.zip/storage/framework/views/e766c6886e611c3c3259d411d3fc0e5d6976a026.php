<!DOCTYPE html>
<html lang="ar" dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>">
    <?php echo $__env->make('website.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .select2-container--default .select2-selection--single{
            border: 1px solid #dee2e6;
            height: 35px;
            padding-top: 2px;
        }
        .select2-container--default .select2-selection--single:focus{
            outline: #F4C20D !important;
            box-shadow: 0 0 0 0.2rem rgba(244, 194, 13, 0.4) !important;
        }
        .select2-container--default .select2-search--dropdown .select2-search__field:focus{
            outline: 0
        }
    </style>
    <body class="bg-white">
        <!-- Header -->
        <?php echo $__env->make('website.includes.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- ./Header -->

        <div style="min-height: 52vh;" id="sat_app_vue">
            <?php echo $__env->yieldContent('website.content'); ?>
        </div>

        <!-- Footer -->
        <?php echo $__env->make('website.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php echo $__env->yieldContent('website.includes.page_scripts'); ?>
        <?php echo $__env->make('website.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH C:\wamp64\www\sat-laravel\resources\views/website/app.blade.php ENDPATH**/ ?>