 <?php $__env->startSection('website.content'); ?>
<!-- Confirm Reservation -->
<section class="confirm-reservation py-4 bg-sub-secondary-color">
    <div class="container-fluid">
        <!-- Section Heading -->
        <div class="row px-xl-5 mb-4">
            <div class="col-12">
                <div class="heading-institutes">
                    <h3 class="text-main-color font-weight-bold">تأكيد الحجز</h3>
                    <p class="mb-1">برجاء ادخل جميع البيانات لتأكيد حجزك وسيقوم فريق الموقع بالتواصل معك لتأكيد جميع التفاصيل لذا تأكد من صحة الجوال والبريد الإلكتروني</p>
                </div>
            </div>
        </div>
        <!-- ./Section Heading -->
        <div class="row px-xl-5">
            <div class="col-lg-8">
                <!-- Confirm Reservation Form -->
                <div class="bg-white p-xl-5 p-3 rounded-10 mb-4">


                    <?php if(session()->has('alert_message')): ?>
                        <div class="text-center">
                            <div class="cheched-img">
                                <img src="<?php echo e(asset('website/imgs/checked.png')); ?>" alt="" class="img-fluid" />
                            </div>
                            <h3 class="text-main-color font-weight-bold"><?php echo e(session()->get('alert_message')['title']); ?></h3>
                            <div class="cheched-heading">
                                <?php echo session()->get('alert_message')['body']; ?>

                            </div>
                        </div>
                    <?php else: ?>
                        <?php if(auth()->guard('student')->check()): ?>
                            <form action="<?php echo e(route('create_student_request')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="course_details" value="<?php echo e(json_encode($course_details)); ?>">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group rounded-10 border pl-3 pr-2 btn-light">
                                            <input readonly   value="<?php echo e(auth()->guard('student')->user()->name); ?>" type="text" name="name" class="form-control border-0 bg-transparent <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="الاسم كاملا *" />
                                        </div>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block mb-3" role="alert"> <strong><?php echo e($message); ?></strong> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group rounded-10 border pl-3 pr-2 btn-light">
                                            <input readonly   value="<?php echo e(auth()->guard('student')->user()->email); ?>" type="email" name="email" class="form-control border-0 bg-transparent <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="البريد الإلكتروني *" />
                                        </div>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block mb-3" role="alert"> <strong><?php echo e($message); ?></strong> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group rounded-10 border pl-3 pr-2 btn-light">
                                            <input readonly   value="<?php echo e(auth()->guard('student')->user()->phone); ?>" type="text" name="phone" class="form-control border-0 bg-transparent <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="رقم الجوال *" />
                                        </div>
                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block mb-3" role="alert"> <strong><?php echo e($message); ?></strong> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group rounded-10 border pl-3 pr-2 btn-light">
                                            <input readonly   value="<?php echo e(auth()->guard('student')->user()->nationality); ?>" type="text" name="nationality" class="form-control border-0 bg-transparent <?php $__errorArgs = ['nationality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="الجنسية *" />
                                        </div>
                                        <?php $__errorArgs = ['nationality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block mb-3" role="alert"> <strong><?php echo e($message); ?></strong> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group rounded-10 border pl-3 pr-2 btn-light">
                                            <input readonly   value="<?php echo e(auth()->guard('student')->user()->country); ?>" type="text" name="country" class="form-control border-0 bg-transparent <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="الدولة *" />
                                        </div>
                                        <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block mb-3" role="alert"> <strong><?php echo e($message); ?></strong> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group rounded-10 border pl-3 pr-2 btn-light">
                                            <input  readonly  value="<?php echo e(auth()->guard('student')->user()->city); ?>" type="text" name="city" class="form-control border-0 bg-transparent <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="المدينة *" />
                                        </div>
                                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block mb-3" role="alert"> <strong><?php echo e($message); ?></strong> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group rounded-10 border pl-3 pr-2 btn-light">
                                            <input readonly   value="<?php echo e(auth()->guard('student')->user()->address); ?>" type="text" name="address" class="form-control border-0 bg-transparent <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="العنوان *" />
                                        </div>
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block mb-3" role="alert"> <strong><?php echo e($message); ?></strong> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-12">
                                        <div class="form-group btn-light rounded-10">
                                            <textarea name="note" class="form-control rounded-10" placeholder="أضف ملاحظاتك" rows="5"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <button class="btn bg-secondary-color text-white w-100 rounded-10" type="submit">
                                            تأكيد الحجز
                                        </button>
                                    </div>
                                </div>
                            </form>
                        <?php else: ?>
                            <form action="<?php echo e(route('create_student_request')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="course_details" value="<?php echo e(json_encode($course_details)); ?>">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group rounded-10 border pl-3 pr-2 btn-light">
                                            <input value="<?php echo e(old('name')); ?>" type="text" name="name" class="form-control border-0 bg-transparent <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="الاسم كاملا *" />
                                        </div>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block mb-3" role="alert"> <strong><?php echo e($message); ?></strong> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
        
                                    <div class="col-lg-6">
                                        <div class="form-group rounded-10 border pl-3 pr-2 btn-light">
                                            <input value="<?php echo e(old('email')); ?>" type="email" name="email" class="form-control border-0 bg-transparent <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="البريد الإلكتروني *" />
                                        </div>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block mb-3" role="alert"> <strong><?php echo e($message); ?></strong> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group rounded-10 border pl-3 pr-2 btn-light">
                                            <input value="<?php echo e(old('phone')); ?>" type="text" name="phone" class="form-control border-0 bg-transparent <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="رقم الجوال *" />
                                        </div>
                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block mb-3" role="alert"> <strong><?php echo e($message); ?></strong> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
        
                                    <div class="col-lg-6">
                                        <div class="form-group rounded-10 border pl-3 pr-2 btn-light">
                                            <input value="<?php echo e(old('nationality')); ?>" type="text" name="nationality" class="form-control border-0 bg-transparent <?php $__errorArgs = ['nationality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="الجنسية *" />
                                        </div>
                                        <?php $__errorArgs = ['nationality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block mb-3" role="alert"> <strong><?php echo e($message); ?></strong> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
        
                                    <div class="col-lg-6">
                                        <div class="form-group rounded-10 border pl-3 pr-2 btn-light">
                                            <input value="<?php echo e(old('country')); ?>" type="text" name="country" class="form-control border-0 bg-transparent <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="الدولة *" />
                                        </div>
                                        <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block mb-3" role="alert"> <strong><?php echo e($message); ?></strong> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group rounded-10 border pl-3 pr-2 btn-light">
                                            <input value="<?php echo e(old('city')); ?>" type="text" name="city" class="form-control border-0 bg-transparent <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="المدينة *" />
                                        </div>
                                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block mb-3" role="alert"> <strong><?php echo e($message); ?></strong> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group rounded-10 border pl-3 pr-2 btn-light">
                                            <input value="<?php echo e(old('address')); ?>" type="text" name="address" class="form-control border-0 bg-transparent <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="العنوان *" />
                                        </div>
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block mb-3" role="alert"> <strong><?php echo e($message); ?></strong> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
        
                                    <div class="col-12">
                                        <div class="form-group btn-light rounded-10">
                                            <textarea name="note" class="form-control rounded-10" placeholder="أضف ملاحظاتك" rows="5"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <button class="btn bg-secondary-color text-white w-100 rounded-10" type="submit">
                                            تأكيد الحجز
                                        </button>
                                    </div>
                                </div>
                            </form>
                        <?php endif; ?>
                    

                    <?php endif; ?>



                    
                </div>
                <!-- ./Confirm Reservation Form -->
            </div>
            <div class="col-lg-4">
                <!-- Course Details -->
                <div class="bg-white py-4 rounded-10 mb-4">
                    <div class="cost-heading border-bottom pb-2 px-3">
                        <h5 class="font-weight-bold text-main-color">تفاصيل الكورس والحجز</h5>
                    </div>
                    <div class="cost-body px-3 pt-3">
                        <p class="text-dark"><span class="font-weight-bold">تكلفة الكورس الإجمالية : </span> <?php echo e(round($course_details['total_price'])); ?> ريال سعودي</p>
                        <p class="text-dark"><span class="font-weight-bold">أسم المعهد : </span> <?php echo e($course_details['institute_name']); ?></p>
                        <p class="text-dark"><span class="font-weight-bold">اسم الكورس : </span> <?php echo e($course_details['course_name']); ?></p>
                        <p class="text-dark"><span class="font-weight-bold">الموقع : </span> <?php echo e($course_details['country']); ?> - <?php echo e($course_details['city']); ?></p>
                        <p class="text-dark"><span class="font-weight-bold">تاريخ بداية الكورس : </span> <?php echo e(ArabicDate($course_details['from_date'])); ?></p>
                        <p class="text-dark"><span class="font-weight-bold">تاريخ نهاية الكورس : </span> <?php echo e(ArabicDate($course_details['to_date'])); ?></p>
                        <?php if($course_details['airport'] != 0): ?>
                        <p class="text-dark"><span class="font-weight-bold">الاستقبال : </span> <?php echo e($course_details['airport']['name_ar']); ?> - <?php echo e($course_details['airport']['price']); ?> ريال سعودي</p>
                        <?php endif; ?> <?php if($course_details['residence'] != 0): ?>
                        <p class="text-dark"><span class="font-weight-bold">تفاصيل السكن : </span> <?php echo e($course_details['residence']['name_ar']); ?> - <?php echo e($course_details['residence']['price']*$course_details['weeks']); ?> ريال سعودي</p>
                        <?php endif; ?> <?php if($course_details['insurance_price'] != 0): ?>
                        <p class="text-dark"><span class="font-weight-bold">التامين : </span> <?php echo e($course_details['insurance_price']*$course_details['weeks']); ?> ريال سعودي</p>
                        <?php endif; ?>
                        <p class="text-dark"><span class="font-weight-bold">عدد الأسابيع : </span> <?php echo e($course_details['weeks']); ?> أسابيع</p>
                        <p class="text-dark"><span class="font-weight-bold">عدد الدروس : </span> <?php echo e($course_details['lessons_per_week']); ?> درس / أسبوع</p>
                        <p class="text-dark"><span class="font-weight-bold">عدد الساعات : </span> <?php echo e($course_details['hours_per_week']); ?> ساعة في الأسبوع</p>
                    </div>
                </div>

               
            </div>
        </div>
    </div>
</section>
<!-- ./Confirm Reservation -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sat-laravel\resources\views/website/institute/confirm-reservation.blade.php ENDPATH**/ ?>