 <?php $__env->startSection('website.content'); ?>

<!-- Profile -->
<section class="profile py-5 bg-sub-secondary-color">
    <div class="container-fluid">
        <div class="row px-xl-5 mb-4">
            <!-- Section Heading -->
            <div class="col-12 d-lg-block d-none">
                <h3 class="text-main-color font-weight-bold">الملف الشخصي</h3>
            </div>
            <!-- ./Section Heading -->
        </div>
        <div class="row px-xl-5">
            <!-- Side Nav -->
            <div class="col-lg-3 mb-4 d-lg-block d-none">
                <?php echo $__env->make('website.students.student-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- ./Side Nav -->
            <?php if(!empty($student->sucess_story)): ?>
                <div class="col-lg-9">
                    <!-- Section Heading -->
                    <h5 class="text-main-color font-weight-bold mb-4">قصة نجاحك <?php echo $student->sucess_story->approvement == 1 ? '<small class="text-success mx-3">(تم قبول قصتك)</small>' : '<small class="text-warning mx-3">(قصتك تحت المراجعة)</small>'; ?></h5>
                    <!-- ./Section Heading -->
                    <div class="bg-white shadow-sm p-xl-5 px-3 py-5 rounded-10">
                        <?php if(session()->has('alert_message')): ?>
                            <div class="alert alert-success text-center">
                                <?php echo e(session()->get('alert_message')); ?>

                            </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('student.update.success.story')); ?>" method="post"  enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($student->sucess_story->id); ?>" name="story_id">
                            <div class="row">
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-lg-12">
                                                <textarea rows="10" type="text" class="form-control rounded-10 <?php $__errorArgs = ['story'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="story"><?php echo e($student->sucess_story->story); ?></textarea>
                                                <?php $__errorArgs = ['story'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    
                                    </div>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-12 mt-3">
                                    <div class="oveflow-hidden">
                                        <button type="submit" class="btn rounded-10 bg-secondary-color text-center text-white float-left px-5">حفظ</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            <?php else: ?>
                <div class="col-lg-9">
                    <h5 class="text-main-color font-weight-bold mb-4">قصة نجاحك</h5>
                    <div class="bg-white shadow-sm p-xl-5 px-3 py-5 rounded-10">
                        <?php if(session()->has('alert_message')): ?>
                            <div class="alert alert-success text-center">
                                <?php echo e(session()->get('alert_message')); ?>

                            </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('student.update.success.story')); ?>" method="post"  enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <label> قصتك</label>
                                                <textarea rows="10" type="text" class="form-control rounded-10 <?php $__errorArgs = ['story'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="story"></textarea>
                                                <?php $__errorArgs = ['story'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    
                                    </div>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-12 mt-3">
                                    <div class="oveflow-hidden">
                                        <button type="submit" class="btn rounded-10 bg-secondary-color text-center text-white float-left px-5">حفظ</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<!-- ./Profile -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sat-laravel\resources\views/website/students/success-story.blade.php ENDPATH**/ ?>