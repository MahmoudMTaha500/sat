

<?php $__env->startSection('website.content'); ?>




<institutes-pgae-component
    :get_courses_url="<?php echo e(json_encode(route('vue.get.courses'))); ?>"
    :public_path="<?php echo e(json_encode(asset('/'))); ?>"
    get_countries_url = "<?php echo e(route('vue.get.countries')); ?>"
    get_cities_url = "<?php echo e(route('vue.get.cities')); ?>"
>
</institutes-pgae-component>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('website.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sat-laravel\resources\views/website/institutes.blade.php ENDPATH**/ ?>