
<?php $__env->startSection('admin.content'); ?>
<?php echo e($department_name = 'country'); ?>

<?php echo e($page_name = 'getcountries'); ?>

    <div class="app-content content">
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-6 col-12 mb-2">
                    <h3 class="content-header-title">قسم الدول</h3>
                    <div class="row breadcrumbs-top">
                        <div class="breadcrumb-wrapper col-12">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">لوحة التحكم</a>
                                </li>
                                <li class="breadcrumb-item active">كل المدن
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>    
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>
                <?php if($message = Session::get('error')): ?>
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>    
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>
                <!-- Recent Transactions -->
                <div class="row">
                    <div id="recent-transactions" class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title"> المدن (<?php echo e(count($cities)); ?>)</h4>
                                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                                <div class="heading-elements">
                                    <ul class="list-inline mb-0">
                                        <li><a class="btn btn-sm btn-success box-shadow-2 round btn-min-width pull-right"
                                                href="<?php echo e(route('city.create')); ?>"> <i class="ft-plus ft-md"></i> اضافة مدينه
                                                جديده</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-content">
                                <div class="table-responsive">
                                    <table id="recent-orders" class="table table-hover table-xl mb-0">
                                        <thead>
                                            <tr>
                                                <th class="border-top-0"> الدوله</th>
                                                <th class="border-top-0"> المدينه</th>
                                             
                                                <th class="border-top-0">اكشن</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td> <?php echo e(\App\country::find($city->country_id)->name_ar); ?></td>
                                                <td> <?php echo e($city->name_ar); ?></td>
                                              
                                                <td class="text-truncate">
                                                        <a href="<?php echo e(route('city.edit' , $city->id)); ?>"><i class="la la-pencil"></i></a>
                                                        <form action="<?php echo e(route('city.destroy' , $city->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field("DELETE"); ?>
                                                            <button  class="btn btn-danger btn-sm"   onclick="return confirm('Are you sure?')"  ><i class="la la-trash"></i></button> 
 
                                                        </form>
                                                    
                                                    
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--/ Recent Transactions -->

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sat-laravel\resources\views/admin/countryandcity/city/index.blade.php ENDPATH**/ ?>