
asdasdas

<script src="https://test.oppwa.com/v1/paymentWidgets.js?checkoutId=<?php echo e($responseData['id']); ?>"></script>
<form action="<?php echo e(route('payment_success')); ?>" class="paymentWidgets" data-brands="VISA MASTER AMEX"></form><?php /**PATH C:\wamp64\www\sat-laravel\resources\views/website/payment/checkout.blade.php ENDPATH**/ ?>