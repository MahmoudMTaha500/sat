 <?php $__env->startSection('website.content'); ?>
<div class="bg-sub-secondary-color">
    <!-- Institutes Offer -->
    <section class="institutes-offer pt-5">
        <div class="container-fluid">
          <!-- Section Heading -->
          <div class="row px-xl-5">
            <div class="col-12">
              <div class="heading-institutes">
    
                <h3 class="text-main-color font-weight-bold">العروض</h3>
                <p>نسعى من خلال عقودنا واتفاقياتنا مع المعاهد والجامعات والمؤسسات الأكاديمية</p>
              </div>
            </div>
          </div>
          <!-- ./Section Heading -->
          <!-- Institute List -->
          <div class="row px-xl-4">
            <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-3 col-md-6">
                            <div class="card mx-xl-4 mx-2 shadow-sm offer border-0 institute-card rounded-10 mb-5">
                                <!-- Offer Icon -->
                                <div class="offer-icon position-absolute bg-secondary-color text-white">
                                    - <?php echo e($offer->discount*100); ?> %
                                </div>
                                <!-- Offer Icon -->
                                <!-- Add To Favourite Btn -->
                                <?php if(auth()->guard('student')->check()): ?>
                                    <div class="add-favourite position-absolute"  course-id="<?php echo e($offer->id); ?>">
                                        <i class="<?php echo e(heart_type($offer)); ?> fa-heart favourite-icon"></i>
                                    </div>
                                <?php endif; ?>
                                <!-- ./Add To Favourite Btn -->
                                <!-- Institute Img -->
                                <a href="<?php echo e(route('website.institute' , [$offer->institute->id, $offer->institute->slug , $offer->slug])); ?>">
                                    <div class="institute-img d-inline-block position-relative">
                                        <img src="../<?php echo e($offer->institute->banner); ?>" alt="<?php echo e($offer->institute->name_ar); ?>" class="card-img-top w-100" />
                                    </div>
                                </a>
                                <!-- ./Institute Img -->
                                <div class="card-body rounded-10 bg-white">
                                    <!-- Institute Title -->
                                    <h5 class="card-title">
                                        <a href="<?php echo e(route('website.institute' , [$offer->institute->id, $offer->institute->slug , $offer->slug])); ?>" class="text-main-color">
                                            معهد <?php echo e($offer->institute->name_ar); ?>

                                        </a>
                                    </h5>
                                    <!-- ./Institute Title -->
                                    <!-- Institute Rate -->
                                    <p class="mb-0"><span class="starrr" ratio="<?php echo e(institute_rate($offer->institute)); ?>"></span> <?php echo e(institute_rate($offer->institute)); ?></p>
                                    <!-- ./Institute Rate -->
                                    <!-- Institute Location -->
                                    <p class="mb-0"><i class="fas fa-map-marker-alt text-main-color"></i> <?php echo e($offer->institute->country->name_ar); ?> , <?php echo e($offer->institute->city->name_ar); ?></p>
                                    <!-- ./Institute Location -->
                                    <!-- Course Name -->
                                    <p class="mb-0"><i class="fas fa-graduation-cap text-main-color"></i> <?php echo e($offer->name_ar); ?></p>
                                    <!-- ./Course Name -->
                                    <!-- Course Time And Level -->
                                    <p class="mb-0 overflow-hidden">
                                        <span class="float-right"><i class="fas fa-sun text-main-color"></i> <?php echo e($offer->study_period=='morning' ? 'صباحي' : 'مسائي'); ?></span>
                                        <span class="float-left"> <i class="fas fa-signal text-main-color"></i> <?php echo e($offer->required_level); ?></span>
                                    </p>
                                    <!-- ./Course Time And Level -->
                                </div>
                                <!-- Course Price -->
                                <div class="card-footer bg-white overflow-hidden">
                                    <del class="text-muted del"><?php echo e(round($offer->coursesPricePerWeek->price)); ?> ريال / أسبوع </del>
                                    <span class="float-left text-main-color"><?php echo e(round($offer->coursesPricePerWeek->price*(1-$offer->discount))); ?> ريال / أسبوع </span>
                                </div>
                                <!-- ./Course Price -->
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
          </div>
            <div class="website-pagination">
                <?php echo e($offers->links()); ?>

            </div>
          <!-- ./Institute List -->
    
        </div>
      </section>
      <!-- ./Institutes Offer -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sat-laravel\resources\views/website/offers.blade.php ENDPATH**/ ?>