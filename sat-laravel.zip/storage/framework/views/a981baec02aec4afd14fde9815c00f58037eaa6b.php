<div class="bg-white rounded-10 py-4 shadow-sm">
    <div class="profile-img pt-4 text-center position-relative mx-auto">
        <img src="<?php echo e($student->profile_image == null ? asset('storage/default__user_image.jpg') : asset($student->profile_image)); ?>" alt="" class="img-fluid rounded-circle" />
        <h6 class="text-main-color font-weight-bold mt-2"><?php echo e($student->name); ?></h6>
    </div>
    <ul class="list-group list-group-flush p-0 border-0">
        <li class="list-group-item py-3 border-bottom <?php echo e($page_title == 'student-profile' ? 'active' : ''); ?>"><a href="<?php echo e(route('student.profile')); ?>" class="<?php echo e($page_title == 'student-profile' ? 'text-white' : ''); ?>">البيانات الشخصية</a></li>
        <li class="list-group-item py-3 border-bottom <?php echo e($page_title == 'student-favourite' ? 'active' : ''); ?>"><a href="<?php echo e(route('student.favourite')); ?>" class="<?php echo e($page_title == 'student-favourite' ? 'text-white' : ''); ?>">المفضلة</a></li>
        <li class="list-group-item py-3 border-bottom <?php echo e($page_title == 'student-reservation' ? 'active' : ''); ?>"><a href="<?php echo e(route('student.reservation')); ?>" class="<?php echo e($page_title == 'student-reservation' ? 'text-white' : ''); ?>">الحجوزات</a></li>
        <li class="list-group-item py-3 <?php echo e($page_title == 'success-story' ? 'active' : ''); ?>"><a href="<?php echo e(route('student.success.story')); ?>" class="<?php echo e($page_title == 'success-story' ? 'text-white' : ''); ?>">قصص النجاح</a></li>
        
    </ul>
</div><?php /**PATH C:\wamp64\www\sat-laravel\resources\views/website/students/student-sidebar.blade.php ENDPATH**/ ?>