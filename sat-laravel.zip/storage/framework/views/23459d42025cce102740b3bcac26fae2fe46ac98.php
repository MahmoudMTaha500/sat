 <?php $__env->startSection('website.content'); ?>

    <!-- Article Img -->
    
    <!-- ./Article Img -->
    <div class="article-img position-relative">
        <img class="w-100" src="<?php echo e(asset($blog->banner)); ?>" alt="" srcset="">
        <div class="overlay"></div>
        <div class="center-content" style="position: absolute;top:50%;left:50%" class="col-lg-4  align-self-center mx-auto text-center">
            <h4 class="text-white mb-4">دراسة اللغة الانجليزية في <?php echo e($blog->country->name_ar); ?> </h4>
            <a href="<?php echo e(route('website.institutes' , ['country' => $blog->country->id])); ?>" class="btn bg-secondary-color text-white rounded-10">معاهد <?php echo e($blog->country->name_ar); ?></a>
        </div>
        <!-- <img src="imgs/news/Bg.png" alt="" class="w-100"> -->
    </div>


    
    <!-- Article -->
    <article class="py-5 bg-sub-secondary-color">
        <div class="container-fluid">

            <div class="row px-xl-5">
                <div class="col-12">
                    <h4 class="text-main-color"><?php echo e($blog->title_ar); ?></h4>
                    <p>  <?php echo $blog->content_ar; ?>  </p>
                </div>
            </div>
        </div>

    </article>
    <!-- ./Article -->
    <!-- Comments -->
    
    <!-- ./Comments -->
    <!-- Footer -->
<?php $__env->stopSection(); ?>








<?php echo $__env->make('website.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sat-laravel\resources\views/website/blog/artical.blade.php ENDPATH**/ ?>