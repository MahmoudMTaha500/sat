 <?php $__env->startSection('admin.content'); ?>
<div class="app-content content vue-app">
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <h3 class="content-header-title">قسم المقالات</h3>
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">لوحة التحكم</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('blogs.index')); ?>"> المقالات</a></li>
                            <li class="breadcrumb-item active">اضافة مقال</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e($message); ?></strong>
            </div>
            <?php endif; ?> <?php if($message = Session::get('error')): ?>
            <div class="alert alert-danger alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e($message); ?></strong>
            </div>
            <?php endif; ?>
            <div class="row justify-content-md-center">
                <div class="col-lg-10">
                    <div class="card" style="zoom: 1;">
                        <div class="card-header">
                            <h4 class="card-title" id="bordered-layout-card-center">اضافة مقال جديد</h4>
                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        </div>
                        <div class="card-content collpase show">
                            <div class="card-body">
                                <?php echo $__env->make('admin.includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <form class="form" action="<?php echo e(route('blogs.store')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-body">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <div class="form-group">
                                                    <label for="projectinput1">العنوان</label>
                                                    <input type="text" id="eventRegInput1" class="form-control" placeholder="ادخل اسم المعهد" name="title_ar" />
                                                </div>
                                                <div class="form-group">
                                                    <label for="projectinput4">المحتوى</label>
                                                    <textarea name="content_ar" id="ckeditor" cols="30" rows="20" class="ckeditor"> </textarea>
                                                </div>


                                            </div>

                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="projectinput2">التصنيف</label>
                                                    <select name="category_id" class="select2 form-control text-left">
                                                        <option value="" selected="" disabled="">اختر التصنيف</option>
                                                            <?php $__currentLoopData = $BlogCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name_ar); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <create-blog-component 
                                                    :countries_from_blade="<?php echo e(json_encode($countries)); ?>" 
                                                    :getcities_url="<?php echo e(json_encode(route('getcities'))); ?>"
                                                    :get_institutes_url="<?php echo e(json_encode(route('blog.get.institutes.vue'))); ?>"
                                                    :get_courses_url="<?php echo e(json_encode(route('blog.get.courses.vue'))); ?>"
                                                >
                                                </create-blog-component>
                                                <show-images-component :image_name="<?php echo e(json_encode("banner")); ?>" :image_label="<?php echo e(json_encode(" اختر الصورة ")); ?>"></show-images-component>
                                            </div>
                                        </div>
                                        <div class="form-actions center">
                                            <button type="submit" class="btn btn-primary w-100"><i class="la la-check-square-o"></i> حفظ</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sat-laravel\resources\views/admin/blogs/create.blade.php ENDPATH**/ ?>