 <?php $__env->startSection('admin.content'); ?>
<div class="app-content content vue-app">
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <h3 class="content-header-title">قسم الموظفين</h3>
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">لوحة التحكم</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('employees.index')); ?>"> الموظفين</a></li>
                            <li class="breadcrumb-item active">اضافة موظف</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">

            <!-- Recent Transactions -->
            <div class="row justify-content-md-center">
                <div class="col-lg-10">
                  <div class="card" style="zoom: 1;">
                    <div class="card-header">
                      <h4 class="card-title" id="bordered-layout-card-center">اضافة موظف جديد</h4>
                      <a  href="/sat/courses/create.php" class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                      
                    </div>
                    <div class="card-content collpase show">
                      <div class="card-body">
                      <form class="form"   action="<?php echo e(route('employees.update',$user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>  
                        <?php echo method_field('put'); ?>
                        <?php echo $__env->make('admin.includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="form-body">
                            <div class="row">
                              <div class="col-md-6">
    
                                <div class="form-group">
                                  <label for="projectinput1">اسم الموظف</label>
                                  <input type="text" id="projectinput1" class="form-control" required placeholder="ادخل اسم الموظف"
                                  name="name" value="<?php echo e($user->name); ?>">
                                </div>
                              </div>
                              <div class="col-md-6">

                                <div class="form-group">
                                  <label for="projectinput2">قسم الموظف</label>
                                  <select class=" form-control text-left" required name="role"  value="<?php echo e($user->role); ?>">
                                      <option     value=""  onclick="admin_emp()">اختر</option>
                                      <option   <?php if($user->hasRole('admin')): ?> selected   <?php endif; ?>  value="admin"  onclick="admin_emp()">ادمن</option>
                                      <option    <?php if($user->hasRole('employee')): ?> selected   <?php endif; ?> value="employee"  id="employee" onclick="employee();"  >موظف</option>
                                   
                                  </select>
                                </div>
                              </div>
                              <div class="col-md-6">

                                <div class="form-group">
                                  <label for="projectinput1">البريد الاليكتروني</label>
                                  <input type="email" id="projectinput1" class="form-control" required placeholder="ادخل البريد الاليكتروني"
                                  name="email"  value="<?php echo e($user->email); ?>">
                                </div>
                              </div>
                              <div class="col-md-6">

                                <div class="form-group">
                                  <label for="projectinput3">كلمه السر </label>
                                  <input type="text" id="projectinput3" rows="20" class="form-control"  placeholder="كلمه السر" name="password"  value="<?php echo e(old('password')); ?>">
                                </div>
                              </div>
                            </div>
                              <div class="row" id="permiossn"       <?php if($user->hasRole('employee')): ?>  style="display: " <?php else: ?>   style="display: none"  <?php endif; ?>  >
                              <div class="col-md-3 mb-3"> 

                                <div class="checkbox">
                                    <h5 for=""> المعاهد</h5>
                                    <label><input      name="permession[]"     <?php if($user->hasPermission('institutes-create')): ?> checked  <?php endif; ?> type="checkbox" value="institutes-create">انشاء</label>
                                  </div>
                                  <div class="checkbox">
                                    <label><input      name="permession[]"   type="checkbox"    <?php if($user->hasPermission('institutes-update')): ?> checked  <?php endif; ?> value="institutes-update">تعديل</label>
                                  </div>
                                  <div class="checkbox  ">
                                    <label><input      name="permession[]"   type="checkbox"   <?php if($user->hasPermission('institutes-read')): ?> checked  <?php endif; ?>  value="institutes-read"  >عرض</label>
                                  </div>
                                   <div class="checkbox  ">
                                    <label><input      name="permession[]"   type="checkbox"    <?php if($user->hasPermission('institutes-delete')): ?> checked  <?php endif; ?>  value="institutes-delete"  >حذف</label>
                                  </div> 
                              </div>
                              <div class="col-md-3"> 

                                <div class="checkbox">
                                    <h5 for=""> الدورات</h5>

                                    <label><input     name="permession[]"    type="checkbox"   <?php if($user->hasPermission('courses-create')): ?> checked  <?php endif; ?> value="courses-create">انشاء</label>
                                  </div>
                                  <div class="checkbox">
                                    <label><input     name="permession[]"    type="checkbox"   <?php if($user->hasPermission('courses-update')): ?> checked  <?php endif; ?> value="courses-update">تعديل</label>
                                  </div>
                                  <div class="checkbox  ">
                                    <label><input      name="permession[]"   type="checkbox"    <?php if($user->hasPermission('courses-read')): ?> checked  <?php endif; ?> value="courses-read"  >عرض</label>
                                  </div>
                                  <div class="checkbox  ">
                                    <label><input      name="permession[]"   type="checkbox"   <?php if($user->hasPermission('courses-delete')): ?> checked  <?php endif; ?> value="courses-delete"  >حذف</label>
                                  </div> 
                              </div>  
                              <div class="col-md-3"> 

                                <div class="checkbox">
                                    <h5 for=""> الدول و المدن</h5>
                                    <label><input     name="permession[]"    type="checkbox"    <?php if($user->hasPermission('cities-countries-create')): ?> checked  <?php endif; ?> value="cities-countries-create">انشاء</label>
                                  </div>
                                  <div class="checkbox">
                                    <label><input     name="permession[]"    type="checkbox"   <?php if($user->hasPermission('cities-countries-update')): ?> checked  <?php endif; ?> value="cities-countries-update">تعديل</label>
                                  </div>
                                  <div class="checkbox  ">
                                    <label><input     name="permession[]"    type="checkbox"   <?php if($user->hasPermission('cities-countries-read')): ?> checked  <?php endif; ?>  value="cities-countries-read"  >عرض</label>
                                  </div>
                                  <div class="checkbox  ">
                                    <label><input      name="permession[]"   type="checkbox"   <?php if($user->hasPermission('cities-countries-delete')): ?> checked  <?php endif; ?> value="cities-countries-delete"  >حذف</label>
                                  </div> 
                              </div>
                              <div class="col-md-3"> 

                                <div class="checkbox">
                                    <h5 for=""> المقالات</h5>

                                    <label><input     name="permession[]"    type="checkbox"    <?php if($user->hasPermission('articals-create')): ?> checked  <?php endif; ?> value="articals-create">انشاء</label>
                                  </div>
                                  <div class="checkbox">
                                    <label><input      name="permession[]"   type="checkbox"    <?php if($user->hasPermission('articals-update')): ?> checked  <?php endif; ?> value="articals-update">تعديل</label>
                                  </div>
                                  <div class="checkbox  ">
                                    <label><input      name="permession[]"   type="checkbox"   <?php if($user->hasPermission('articals-read')): ?> checked  <?php endif; ?> value="articals-read"  >عرض</label>
                                  </div>
                                  <div class="checkbox  ">
                                    <label><input     name="permession[]"    type="checkbox"   <?php if($user->hasPermission('articals-delete')): ?> checked  <?php endif; ?> value="articals-delete"  >حذف</label>
                                  </div> 
                              </div>  
                              <div class="col-md-3"> 

                                <div class="checkbox">
                                    <h5 for=""> الخدمات</h5>
                                    <label><input      name="permession[]"   type="checkbox"   <?php if($user->hasPermission('services-create')): ?> checked  <?php endif; ?> value="services-create">انشاء</label>
                                  </div>
                                  <div class="checkbox">
                                    <label><input     name="permession[]"    type="checkbox"   <?php if($user->hasPermission('services-update')): ?> checked  <?php endif; ?> value="services-update">تعديل</label>
                                  </div>
                                  <div class="checkbox  ">
                                    <label><input     name="permession[]"    type="checkbox"   <?php if($user->hasPermission('services-read')): ?> checked  <?php endif; ?> value="services-read"  >عرض</label>
                                  </div>
                                  <div class="checkbox  ">
                                    <label><input      name="permession[]"   type="checkbox"   <?php if($user->hasPermission('services-delete')): ?> checked  <?php endif; ?> value="services-delete"  >حذف</label>
                                  </div> 
                              </div>
                              <div class="col-md-3"> 

                                <div class="checkbox">
                                    <h5 for=""> الطلاب</h5>

                                    <label><input      name="permession[]"   type="checkbox"   <?php if($user->hasPermission('students-create')): ?> checked  <?php endif; ?> value="students-create">انشاء</label>
                                  </div>
                                  <div class="checkbox">
                                    <label><input      name="permession[]"   type="checkbox"   <?php if($user->hasPermission('students-update')): ?> checked  <?php endif; ?> value="students-update">تعديل</label>
                                  </div>
                                  <div class="checkbox  ">
                                    <label><input     name="permession[]"   type="checkbox"    <?php if($user->hasPermission('students-read')): ?> checked  <?php endif; ?> value="students-read"  >عرض</label>
                                  </div>
                                  <div class="checkbox  ">
                                    <label><input     name="permession[]"    type="checkbox"   <?php if($user->hasPermission('students-delete')): ?> checked  <?php endif; ?> value="students-delete"  >حذف</label>
                                  </div> 
                              </div>  
                              <div class="col-md-3"> 

                                <div class="checkbox">
                                    <h5 for=""> طلابات الطلابه</h5>
                                    <label><input      name="permession[]"   type="checkbox"   <?php if($user->hasPermission('student-requests-create')): ?> checked  <?php endif; ?> value="student-requests-create">انشاء</label>
                                  </div>
                                  <div class="checkbox">
                                    <label><input     name="permession[]"    type="checkbox"   <?php if($user->hasPermission('student-requests-update')): ?> checked  <?php endif; ?> value="student-requests-update">تعديل</label>
                                  </div>
                                  <div class="checkbox  ">
                                    <label><input     name="permession[]"    type="checkbox"   <?php if($user->hasPermission('student-requests-read')): ?> checked  <?php endif; ?> value="student-requests-read"  >عرض</label>
                                  </div>
                                  <div class="checkbox  ">
                                    <label><input     name="permession[]"    type="checkbox"    <?php if($user->hasPermission('student-requests-delete')): ?> checked  <?php endif; ?> value="student-requests-delete"  >حذف</label>
                                  </div> 
                              </div>
                              <div class="col-md-3"> 

                                <div class="checkbox">
                                    <h5 for=""> الفيزا</h5>
                                    <label><input     name="permession[]"    type="checkbox"  <?php if($user->hasPermission('visas-create')): ?> checked  <?php endif; ?> value="visas-create">انشاء</label>
                                  </div>
                                  <div class="checkbox">
                                    <label><input     name="permession[]"    type="checkbox"   <?php if($user->hasPermission('visas-update')): ?> checked  <?php endif; ?> value="visas-update">تعديل</label>
                                  </div>
                                  <div class="checkbox  ">
                                    <label><input     name="permession[]"    type="checkbox"   <?php if($user->hasPermission('visas-read')): ?> checked  <?php endif; ?> value="visas-read"  >عرض</label>
                                  </div>
                                  <div class="checkbox  ">
                                    <label><input      name="permession[]"   type="checkbox"   <?php if($user->hasPermission('visas-delete')): ?> checked  <?php endif; ?> value="visas-delete"  >حذف</label>
                                  </div> 
                              </div>
                            </div>
                            
                            </div>
                            <div class="form-actions center">
                              <button type="submit" class="btn btn-primary w-100">
                                <i class="la la-check-square-o"></i> حفظ
                              </button>
                            </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            <!--/ Recent Transactions -->
    
          </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin.custom-js-scripts'); ?>
    <script>
function employee(){
var emp = document.getElementById('employee').value;
document.getElementById("permiossn").style.display = "";
// $("#permiossn").style('','');



}
function admin_emp(){
document.getElementById("permiossn").style.display = "none";

}
// if(emp == 3){
//     alert(emp)

// }

// $("#employee").click(function(){
//     alert(21321231);
// })


         function vaildate(){
$('form').submit(function(e) {
      var err = 0;
      $('.vaildate').each(function(e){
            // alert(this.value);
            if (!$(this).val()) {
              err = 1;
            }
        });
      if (err != 0) {
alert("يرجي ادخل اسعار الدورة");
        return false;
      }
    //   console.log('submitted');
    });
    }
    $(document).on('click' , '.test-btn' , function(){
      vaildate()
    })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sat-laravel\resources\views/admin/employees/edit.blade.php ENDPATH**/ ?>