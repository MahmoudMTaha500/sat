 <?php $__env->startSection('admin.content'); ?>
<div class="app-content content vue-app">
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <h3 class="content-header-title">قسم الطلابات</h3>
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">لوحة التحكم</a></li>
                            <li class="breadcrumb-item active">تعديل الطلب</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
           
            <div class="row justify-content-md-center">
                <div class="col-lg-10">
                    <div class="card" style="zoom: 1;">
                        <div class="card-header">
                            <h4 class="card-title" id="bordered-layout-card-center">تعديل الطلب</h4>
                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        </div>
                        <div class="card-content collpase show">
                            <div class="card-body">
                                <?php echo $__env->make('admin.includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <student-request-edit-component
                                     :student_requests_url="<?php echo e(json_encode( url('/dashboard/student-requests'))); ?>"
                                     :student_request="<?php echo e(json_encode($student_request)); ?>"
                                     get_insurance_price_url = <?php echo e(route('vue.get.insurance.price.per.week')); ?>

                                     get_course_price_url = <?php echo e(route('vue.get.course.price.per.week')); ?>

                                     csrf_token =  "<?php echo e(csrf_token()); ?>"
                                ></student-request-edit-component>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sat-laravel\resources\views/admin/students_requests/edit.blade.php ENDPATH**/ ?>