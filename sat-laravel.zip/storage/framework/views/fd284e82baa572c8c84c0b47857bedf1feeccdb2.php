
<?php /**PATH C:\wamp64\www\sat-laravel\resources\views/website/includes/alerts.blade.php ENDPATH**/ ?>