 <?php $__env->startSection('website.content'); ?>

<!-- Profile -->
<section class="profile py-5 bg-sub-secondary-color">
    <div class="container-fluid">
        <div class="row px-xl-5 mb-4">
            <!-- Section Heading -->
            <div class="col-12 d-lg-block d-none">
                <h3 class="text-main-color font-weight-bold">الملف الشخصي</h3>
            </div>
            <!-- ./Section Heading -->
        </div>
        <div class="row px-xl-5">
            <!-- Side Nav -->
            <div class="col-lg-3 mb-4 d-lg-block d-none">
                <?php echo $__env->make('website.students.student-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- ./Side Nav -->
            <div class="col-lg-9">
                <!-- Section Heading -->
                <div class="heading overflow-hidden mb-4">
                    <span class="text-main-color font-weight-bold h5 d-inline-block pt-2">
                        الحجوزات
                    </span>
                </div>
                <!-- ./Section Heading -->
                <!-- Reservation List -->
                <div class="reservation-list">
                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="accordion mb-4" id="reservation-1">
                        <div class="card rounded-10 border-0">
                            

                            <div id="reservationCollapse-<?php echo e($request->id); ?>" class="collapse show" aria-labelledby="reservationHeading-<?php echo e($request->id); ?>" data-parent="#reservation-1">
                                <div class="card-body">
                                    <p><span class="font-weight-bold">أجمالي تكاليف الدورة :</span> <?php echo e($request->total_price); ?> ريال سعودي</p>
                                    <p><span class="font-weight-bold">أسم المعهد :</span> معهد <?php echo e($request->course->institute->name_ar); ?></p>
                                    <p><span class="font-weight-bold">الدولة :</span><?php echo e($request->course->institute->country->name_ar); ?></p>
                                    <p><span class="font-weight-bold">المدينة :</span><?php echo e($request->course->institute->city->name_ar); ?></p>
                                    <p><span class="font-weight-bold">تاريخ الحجز :</span><?php echo e(ArabicDate($request->created_at)); ?></p>
                                    <div class="overflow-hidden">
                                        <button data-toggle="modal" data-target="#request<?php echo e($request->id); ?>" class="btn float-left bg-secondary-color text-white rounded-10">تفاصيل الدورة</button>
                                    </div>
                                    
                                    <!-- Modal -->
                                        <div class="modal fade" id="request<?php echo e($request->id); ?>" tabindex="-1" aria-labelledby="successModalLabel"
                                        aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-body py-5 px-4">
                                                    <div class="card-body">
                            
                                                        <p><span class="font-weight-bold">أجمالي تكاليف الدورة :</span> <?php echo e($request->total_price); ?> ريال سعودي</p>
                                                            
                                                        <p><span class="font-weight-bold">أسم المعهد :</span> معهد <?php echo e($request->course->institute->name_ar); ?></p>
                                                        <p><span class="font-weight-bold">اسم الدورة :</span> لغة <?php echo e($request->course->name_ar); ?></p>
                                                        <p><span class="font-weight-bold">الدولة :</span><?php echo e($request->course->institute->country->name_ar); ?></p>
                                                        <p><span class="font-weight-bold">المدينة :</span><?php echo e($request->course->institute->city->name_ar); ?></p>
                                                        <p><span class="font-weight-bold">تاريخ بداية الدورة :</span><?php echo e(ArabicDate($request->from_date)); ?></p>
                                                        <p><span class="font-weight-bold">تاريخ إنتهاء  الدورة :</span><?php echo e(ArabicDate($request->to_date)); ?></p>
                                                        <p><span class="font-weight-bold">عدد الأسابيع :</span><?php echo e($request->weeks); ?> أسابيع</p>
                                                        <p><span class="font-weight-bold">عدد الدروس :</span><?php echo e($request->course->lessons_per_week); ?> درس / أسبوع</p>
                                                        <p><span class="font-weight-bold">عدد الساعات :</span><?php echo e($request->course->hours_per_week); ?> ساعة في الأسبوع</p>
                                                        <p><span class="font-weight-bold">تاريخ الحجز :</span><?php echo e(ArabicDate($request->created_at)); ?></p>
                                                        <div class="border-top py-3">
                                                            <h5 class="text-main-color font-weight-bold mb-3">الدفعات</h5>
                                                            <p><span class="font-weight-bold">المدفوع :</span> <?php echo e($request->paid_price); ?>  ريال سعودي</p>
                                                            <p><span class="font-weight-bold">المتبقي :</span> <?php echo e($request->remaining_price); ?>  ريال سعودي</p>
                                                        </div>
                                                        <div class="border-top py-3">
                                                            <h5 class="text-main-color font-weight-bold mb-3">حالة الطلب</h5>
                                                            <p><span class="font-weight-bold">
                                                                <?php echo e($request->status == 'جديد' ? 'طلبك قيد المراجعة' : ''); ?>

                                                                <?php echo $request->status == 'حصل علي قبول' ? '<span class="text-success">تم قبول طلبك</span>' : ''; ?> 
                                                                <?php echo $request->status == 'بداء الدراسة' ? '<span class="text-success">تم بداء دراستك</span>' : ''; ?> 
                                                                <?php echo $request->status == 'مرفوض' ? '<span class="text-danger">تم رفض طلبك</span>' : ''; ?> 
                                                            </span> </p>
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- ./Reservation List -->
            </div>
        </div>
    </div>
</section>
<!-- ./Profile -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sat-laravel\resources\views/website/students/reservation.blade.php ENDPATH**/ ?>