

<?php $__env->startSection('website.content'); ?>
    <div dir="rtl">
        <div>
            <h1>فورم البحث الخاص بالهيدر</h1>
            <form action="">
                <input type="text" name="">
                <button type="submit">بحث</button>
            </form>
            <hr>
        </div>
        <div>
            <h1>الفيلتر المبدئ في تاني سيكشن</h1>
            <form action="">
                <country-component 
                    ref="countries_ref"
                    get_countries_url = "<?php echo e(route('vue.get.countries')); ?>"
                >
                </country-component>
                <city-component 
                    ref="cities_ref"
                    get_cities_url = "<?php echo e(route('vue.get.cities')); ?>"
                >
                </city-component>
                <select name="">
                    <option hidden value="">عدد الاسابيع</option>
                    <?php for($i = 1; $i <=100 ;$i++): ?>
                        <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                    <?php endfor; ?>
                </select>
                <div>
                    <label>افضل العروض</label>
                    <input type="checkbox" name="" id="">
                </div>
                <div>
                    <label>الاعلى تقيما</label>
                    <input type="checkbox" name="" id="">
                </div>
                <div>
                    <label>الاكثر استخداما</label>
                    <input type="checkbox" name="" id="">
                </div>
                <button type="submit">بحث</button>
            </form>
            <hr>
        </div>
    
        <div>
            <h1>افضل العروض</h1>
                <?php $__currentLoopData = $best_offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(url($offer->slug)); ?>">
                        <div style="width: 19.5%;display:inline-block">
                            <img width="100%" src="<?php echo e($offer->institute->banner); ?>" alt="<?php echo e($offer->institute->name_ar); ?>" >
                            <h3>معهد <?php echo e($offer->institute->name_ar); ?> </h3>
                            <p><?php echo e(institute_rate($offer->institute)); ?></p>
                            <p><?php echo e($offer->institute->country->name_ar); ?> , <?php echo e($offer->institute->city->name_ar); ?></p>
                            <p><?php echo e($offer->name); ?></p>
                            <p><?php echo e($offer->study_period=='morning' ? 'صباحي' : 'مسائي'); ?></p>
                            <p><?php echo e($offer->required_level); ?></p>
                            <p><?php echo e($offer->coursesPricePerWeek->price*(1-$offer->discount)); ?></p>
                            <del><?php echo e($offer->coursesPricePerWeek->price); ?></del>
                            <p><?php echo e($offer->discount*100); ?> %</p>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <hr>
        </div>
    
    
        <div>
            <h1>قصص النجاح</h1>
                <?php $__currentLoopData = $success_stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div style="width: 19.5%;display:inline-block">
                        <img width="100%" src="<?php echo e($story->student->profile_image == null ? asset('storage/default_images.png') : $story->student->profile_image); ?>" alt="<?php echo e($story->student->name); ?>" >
                        <h3> <?php echo e($story->student->name); ?> </h3>
                        <p><?php echo e($story->story); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <hr>
        </div>
    
        <div>
            <h1>قصص النجاح</h1>
                <div style="width: 49%;display:inline-block">
                    <img width="100%" src="<?php echo e($two_blogs[0]->banner == null ? asset('storage/default_images.png') : $two_blogs[0]->banner); ?>" alt="<?php echo e($two_blogs[0]->title_ar); ?>" >
                    <h2> <?php echo e($two_blogs[0]->title_ar); ?> </h2>
                    <p><?php echo e($two_blogs[0]->content_ar); ?></p>
                    <a href="<?php echo e($two_blogs[0]->country->id); ?>">عرض معاهد <?php echo e($two_blogs[0]->country->name_ar); ?></a><br>
                    <a href="<?php echo e($two_blogs[0]->id); ?>">معرفة المزيد</a><br>
                    <a href="#">دول اخري</a>
                </div>
                <div style="width: 49%;display:inline-block">
                    <img width="100%" src="<?php echo e($two_blogs[1]->banner == null ? asset('storage/default_images.png') : $two_blogs[1]->banner); ?>" alt="<?php echo e($two_blogs[1]->title_ar); ?>" >
                    <h2> <?php echo e($two_blogs[1]->title_ar); ?> </h2>
                    <p><?php echo e($two_blogs[1]->content_ar); ?></p>
                    <a href="<?php echo e($two_blogs[1]->country->id); ?>">عرض معاهد <?php echo e($two_blogs[1]->country->name_ar); ?></a><br>
                    <a href="<?php echo e($two_blogs[1]->id); ?>">معرفة المزيد</a><br>
                    <a href="#">دول اخري</a>
                </div>
            <hr>
        </div>
        <div>
            <h1>من وثقوا بنا</h1>
            <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="width: 16.5%;display:inline-block">
                    <img width="100%" src="<?php echo e($partner->logo == null ? asset('storage/default_images.png') : $partner->logo); ?>" alt="<?php echo e($partner->name); ?>" >
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <hr>
        </div>
        <div>
            <h1>أخر الأخبار و الموضوعات المهمة</h1>
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($blog->id); ?>">
                    <div style="width: 16.5%;display:inline-block">
                        <img width="24.8%" src="<?php echo e($blog->banner == null ? asset('storage/default_images.png') : $blog->banner); ?>" alt="<?php echo e($blog->title_ar); ?>" >
                        <a href="<?php echo e($blog->id); ?>"><h2> <?php echo e($blog->title_ar); ?> </h2></a>
                        <p><?php echo e($blog->creator->name); ?></p>
                        <p> <?php echo e(ArabicDate($blog->created_at)); ?></p>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <hr>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sat-laravel\resources\views/website/home_page.blade.php ENDPATH**/ ?>