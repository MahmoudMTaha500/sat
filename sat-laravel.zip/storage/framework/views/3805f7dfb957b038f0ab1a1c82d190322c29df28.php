 <?php $__env->startSection('website.content'); ?>
  <!-- Articles -->
  <section class="articles py-4 bg-sub-secondary-color">
    <div class="container-fluid">
        <!-- Section Heading -->
        <div class="row px-xl-5">
            <div class="col-12">
                <div class="heading-institutes">

                    <h3 class="text-main-color font-weight-bold">المقالات</h3>
                    <p>تصفح جميع المقالات الخاصة بدراسة اللغة حول العالم</p>
                </div>
            </div>
        </div>
        <!-- ./Section Heading -->
        <!-- Articles List -->
        <div class="row px-xl-4 mb-5">

            <div class="col-12">
                <div class="articles-list pt-4">

                    <div class="row">

                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-3 col-md-4 mb-5">
                            <!-- Article -->
                            <div class="card mx-xl-4 mx-2 shadow-sm offer border-0 rounded-10">
                                    <a href="<?php echo e(route('website.article',$blog->id)); ?>">
                                        <img src="<?php echo e($blog->banner == null ? asset('storage/default_images.png') : $blog->banner); ?>" alt="<?php echo e($blog->title_ar); ?>" class="card-img-top" />
                                    </a>
                                    <div class="card-body rounded-10 bg-white">
                                        <a href="<?php echo e(route('website.article',$blog->id)); ?>"><h5 class="card-title text-main-color"><?php echo e($blog->title_ar); ?></h5></a>
                                        <p class="mb-0">
                                            <span><?php echo mb_substr($blog->content_ar ,0 , 150 , 'utf-8'); ?> ... <a href="<?php echo e(route('website.article',$blog->id)); ?>">المزيد</a></span>
                                        </p>
                                        <p class="mb-0"><span class="text-muted"><?php echo e(ArabicDate($blog->created_at)); ?></span></p>
                                    </div>
                                </div>
                            <!-- ./Article -->
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        
                       
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ./Articles List -->
        <!-- Pagination -->
        <div class="row px-xl-5">
            <div class="col-12">
                <nav aria-label="Page navigation  ">
                    <div class="website-pagination">
                        <?php echo e($blogs->links()); ?>

                    </div>
                </nav>
            </div>
        </div>
        <!-- ./Pagination -->
    </div>
</section>
<!-- ./Articles -->
<?php $__env->stopSection(); ?>








<?php echo $__env->make('website.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sat-laravel\resources\views/website/blog/articles.blade.php ENDPATH**/ ?>