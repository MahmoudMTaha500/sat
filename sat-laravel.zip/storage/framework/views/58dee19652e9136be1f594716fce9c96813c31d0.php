 <?php $__env->startSection('website.content'); ?>

<!-- Profile -->
<section class="profile py-5 bg-sub-secondary-color">
    <div class="container-fluid">
        <div class="row px-xl-5 mb-4">
            <!-- Section Heading -->
            <div class="col-12 d-lg-block d-none">
                <h3 class="text-main-color font-weight-bold">الملف الشخصي</h3>
            </div>
            <!-- ./Section Heading -->
        </div>
        <div class="row px-xl-5">
            <!-- Side Nav -->
            <div class="col-lg-3 mb-4 d-lg-block d-none">
                <?php echo $__env->make('website.students.student-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- ./Side Nav -->
            <div class="col-lg-9">
                <!-- Section Heading -->
                <h5 class="text-main-color font-weight-bold mb-4">المفضلة</h5>
                <!-- ./Section Heading -->
                <div class="bg-white shadow-sm p-xl-5 p-2 rounded-10">
                    <div class="row">
                        <?php $__currentLoopData = $favourites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favourite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-4 col-md-6">
                            <div class="card mx-xl-4 mx-2 shadow-sm offer border-0 institute-card rounded-10 mb-5">
                                <!-- Offer Icon -->
                                <div class="offer-icon position-absolute bg-secondary-color text-white">
                                    - <?php echo e($favourite->course->discount*100); ?> %
                                </div>
                                <!-- Offer Icon -->
                                <!-- Add To Favourite Btn -->
                                <div class="add-favourite position-absolute" course-id="<?php echo e($favourite->course->id); ?>">
                                    <i class="fas fa-heart favourite-icon"></i>
                                </div>
                                <!-- ./Add To Favourite Btn -->
                                <!-- Institute Img -->
                                <a href="<?php echo e(route('website.institute' , [$favourite->course->institute->id, $favourite->course->institute->slug , $favourite->course->slug])); ?>">
                                    <div class="institute-img d-inline-block position-relative">
                                        <img src="../<?php echo e($favourite->course->institute->banner); ?>" alt="<?php echo e($favourite->course->institute->name_ar); ?>" class="card-img-top w-100" />
                                    </div>
                                </a>
                                <!-- ./Institute Img -->
                                <div class="card-body rounded-10 bg-white">
                                    <!-- Institute Title -->
                                    <h5 class="card-title">
                                        <a href="<?php echo e(route('website.institute' , [$favourite->course->institute->id, $favourite->course->institute->slug , $favourite->course->slug])); ?>" class="text-main-color">
                                            معهد <?php echo e($favourite->course->institute->name_ar); ?>

                                        </a>
                                    </h5>
                                    <!-- ./Institute Title -->
                                    <!-- Institute Rate -->
                                    <p class="mb-0"><span class="starrr" ratio="<?php echo e(institute_rate($favourite->course->institute)); ?>"></span> <?php echo e(institute_rate($favourite->course->institute)); ?></p>
                                    <!-- ./Institute Rate -->
                                    <!-- Institute Location -->
                                    <p class="mb-0"><i class="fas fa-map-marker-alt text-main-color"></i> <?php echo e($favourite->course->institute->country->name_ar); ?> , <?php echo e($favourite->course->institute->city->name_ar); ?></p>
                                    <!-- ./Institute Location -->
                                    <!-- Course Name -->
                                    <p class="mb-0"><i class="fas fa-graduation-cap text-main-color"></i> <?php echo e($favourite->course->name_ar); ?></p>
                                    <!-- ./Course Name -->
                                    <!-- Course Time And Level -->
                                    <p class="mb-0 overflow-hidden">
                                        <span class="float-right"><i class="fas fa-sun text-main-color"></i> <?php echo e($favourite->course->study_period=='morning' ? 'صباحي' : 'مسائي'); ?></span>
                                        <span class="float-left"> <i class="fas fa-signal text-main-color"></i> <?php echo e($favourite->course->required_level); ?></span>
                                    </p>
                                    <!-- ./Course Time And Level -->
                                </div>
                                <!-- Course Price -->
                                <div class="card-footer bg-white overflow-hidden">
                                    <del class="text-muted del"><?php echo e(round($favourite->course->coursesPricePerWeek->price)); ?> ريال / أسبوع </del>
                                    <span class="float-left text-main-color"><?php echo e(round($favourite->course->coursesPricePerWeek->price*(1-$favourite->course->discount))); ?> ريال / أسبوع </span>
                                </div>
                                <!-- ./Course Price -->
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ./Profile -->


<?php $__env->stopSection(); ?> 
<?php echo $__env->make('website.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sat-laravel\resources\views/website/students/favourite.blade.php ENDPATH**/ ?>